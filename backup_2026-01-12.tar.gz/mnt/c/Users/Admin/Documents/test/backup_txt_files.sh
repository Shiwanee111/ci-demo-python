#!/bin/bash

BACKUP_DIR="$HOME/backup"
mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +"%Y-%m-%d_%H-%M-%S")

for file in *.txt; do
    [ -e "$file" ] || continue
    filename=$(basename "$file" .txt)
    cp "$file" "$BACKUP_DIR/${filename}_${TIMESTAMP}.txt"
done

echo "Backup completed successfully."


