#!/bin/bash

LOG_FILE="system_health.log"
DATE=$(date "+%Y-%m-%d %H:%M:%S")

# Get CPU usage
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print 100 - $8}')

# Get Memory usage
TOTAL_MEM=$(free | grep Mem | awk '{print $2}')
AVAILABLE_MEM=$(free | grep Mem | awk '{print $7}')
MEM_AVAILABLE_PERCENT=$(( AVAILABLE_MEM * 100 / TOTAL_MEM ))

echo "[$DATE] CPU Usage: $CPU_USAGE% | Available Memory: $MEM_AVAILABLE_PERCENT%" >> $LOG_FILE

# Check CPU threshold
if (( $(echo "$CPU_USAGE > 80" | bc -l) )); then
    echo "[$DATE] WARNING: CPU usage is above 80%" >> $LOG_FILE
fi

# Check Memory threshold
if [ "$MEM_AVAILABLE_PERCENT" -lt 20 ]; then
    echo "[$DATE] WARNING: Available memory is below 20%" >> $LOG_FILE
fi

